<?php
// created: 2015-08-13 16:36:22
$dictionary["fox_Course"]["fields"]["fox_course_contacts"] = array (
  'name' => 'fox_course_contacts',
  'type' => 'link',
  'relationship' => 'fox_course_contacts',
  'source' => 'non-db',
  'module' => 'Contacts',
  'bean_name' => 'Contact',
  'vname' => 'LBL_FOX_COURSE_CONTACTS_FROM_CONTACTS_TITLE',
);
