<?php
// created: 2015-08-13 16:36:22
$dictionary["Contact"]["fields"]["fox_course_contacts"] = array (
  'name' => 'fox_course_contacts',
  'type' => 'link',
  'relationship' => 'fox_course_contacts',
  'source' => 'non-db',
  'module' => 'fox_Course',
  'bean_name' => 'fox_Course',
  'vname' => 'LBL_FOX_COURSE_CONTACTS_FROM_FOX_COURSE_TITLE',
);
