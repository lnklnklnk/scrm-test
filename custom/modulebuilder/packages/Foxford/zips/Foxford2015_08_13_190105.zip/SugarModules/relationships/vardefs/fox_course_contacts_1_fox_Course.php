<?php
// created: 2015-08-13 19:01:05
$dictionary["fox_Course"]["fields"]["fox_course_contacts_1"] = array (
  'name' => 'fox_course_contacts_1',
  'type' => 'link',
  'relationship' => 'fox_course_contacts_1',
  'source' => 'non-db',
  'module' => 'Contacts',
  'bean_name' => 'Contact',
  'vname' => 'LBL_FOX_COURSE_CONTACTS_1_FROM_CONTACTS_TITLE',
);
