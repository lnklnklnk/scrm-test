<?php
//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_FOX_COURSE_CONTACTS_FROM_CONTACTS_TITLE'] = 'В моих курсах у';
$mod_strings['LBL_FOX_COURSE_CONTACTS_1_FROM_CONTACTS_TITLE'] = 'Куплен пользователями';
