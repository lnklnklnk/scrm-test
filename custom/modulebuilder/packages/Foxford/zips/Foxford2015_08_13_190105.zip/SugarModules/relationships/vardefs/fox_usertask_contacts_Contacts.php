<?php
// created: 2015-08-13 19:01:05
$dictionary["Contact"]["fields"]["fox_usertask_contacts"] = array (
  'name' => 'fox_usertask_contacts',
  'type' => 'link',
  'relationship' => 'fox_usertask_contacts',
  'source' => 'non-db',
  'module' => 'fox_UserTask',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_FOX_USERTASK_CONTACTS_FROM_FOX_USERTASK_TITLE',
);
