<?php
// created: 2015-08-13 19:01:05
$dictionary["Contact"]["fields"]["fox_course_contacts_1"] = array (
  'name' => 'fox_course_contacts_1',
  'type' => 'link',
  'relationship' => 'fox_course_contacts_1',
  'source' => 'non-db',
  'module' => 'fox_Course',
  'bean_name' => 'fox_Course',
  'vname' => 'LBL_FOX_COURSE_CONTACTS_1_FROM_FOX_COURSE_TITLE',
);
